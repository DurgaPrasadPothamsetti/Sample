import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hero-list',
  templateUrl: './hero-list.component.html',
  styleUrls: ['./hero-list.component.css']
})
export class HeroListComponent implements OnInit {

  heros: any[]=[{name:"Leela",id:"185512"},{name: "Sunil Kumar",id:"186958"},{name:"Harsha", id:"18697"},{name:"Sandeep",id:"252514"}];
  her: any;
  eid : any;
  constructor() { }

  ngOnInit() {
  }
  clickHero(hero){
    this.her="Your Selection is: "+hero.name;
    this.eid=hero.name+"'s Id is : "+hero.id;
  }
  resetPage(): void {
    window.location.reload();
}
}
