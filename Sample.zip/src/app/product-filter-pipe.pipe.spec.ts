import { ProductFilterPipePipe } from './product-filter-pipe.pipe';

describe('ProductFilterPipePipe', () => {
  it('create an instance', () => {
    const pipe = new ProductFilterPipePipe();
    expect(pipe).toBeTruthy();
  });
});
